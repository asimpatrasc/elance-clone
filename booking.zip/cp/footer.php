</div>
<div class="clr"></div>
</div>
</div>
<div class="clr"></div>
<div id="footer">
 <p class="fl-left">Hotel Booking System v2.0</p>
 <p class="fl-right">© 2008 - 2012 Copyright <a href="http://www.bestsoftinc.com" target="_blank" style="color:#CCC;">Best Soft Inc</a> </p>
</div>
</body></html>